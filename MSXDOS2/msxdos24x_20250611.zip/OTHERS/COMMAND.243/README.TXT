-----------------------------------------------------------------------------------------------------------
- MSXDOS2.SYS 2.33 by Hardware Partners Nederland / KdL
- COMMAND2.COM 2.43 by C.P.U./ Hardware Partners Nederland / KdL
-----------------------------------------------------------------------------------------------------------


MSXDOS2.SYS 2.32 by Hardware Partners Nederland:
- Adapted version of 2.31 by ASCII Corporation.
- Added a new Debug Mode for experiments.
- Other... ???

MSXDOS2.SYS 2.33 by KdL:
- Updated the MSXDOS2.SYS version to "2.33".
- Fixed the background and border colors that were swapped for error into Debug Mode.
- Added a switch for Debug Mode on border color "1".
  Usage: COLOR,,1:SETSCREEN from BASIC to enable Debug Mode; with any other colors was disabled.
- CONFIG.BAT filename (modified by H.P.N.) was restored as REBOOT.BAT for compatibility.

Warning:
- This MSXDOS2.SYS 2.33 is not the version realized by Desire In Envy.
-----------------------------------------------------------------------------------------------------------

COMMAND2.COM 2.42 by Hardware Partners Nederland:
- Adapted version of 2.41 by C.P.U.
- Fixed the system crash using TAB key inside of any empty folders.
- Semplified the "MEMORY" command for alias group.
- Other... ???

COMMAND2.COM 2.43 by KdL:
- Updated the COMMAND2.COM version to "2.43".
- Updated the _DOSVER environment item to the current version.
- Recovered the "FORMAT" command inhibited previously.
- Fixed the corrupted ")skCheck is " string text with "DiskCheck is ".
- Updated the HELP folder.
- Added the UTILS folder.
- The original H.P.N. file was restored and disinfected by TCAV antivirus.
- This file was updated by Okey's COMPATCH.COM to support FAT16 partitions.
-----------------------------------------------------------------------------------------------------------

Note:
- These files may be mixed with other versions of them.

External links:
COMMAND2.COM 2.40/1 => http://www.mccw.hetlab.tk/93/dos240/nl.html
Okey's COMPATCH.COM => http://www.msx.org/modules.php?op=modload&name=Downloads&file=index&req=visit&lid=3
COMMAND2.COM 2.44   => http://www.tni.nl/products/command2.html

-----------------------------------------------------------------------------------------------------------
KdL, 2010.11.30
-----------------------------------------------------------------------------------------------------------
